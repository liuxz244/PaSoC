package PaSoC

import Consts._

import chisel3._       // chisel本体
import chisel3.util._  // chisel功能
import chisel3.util.experimental.loadMemoryFromFileInline  // 向存储器写入初始值


// 定义指令存储器模块
class InstMemory extends Module {
  val io = IO(new ImemPortIo())

  // 使用 SyncReadMem 替代 Mem, 才能综合为 FPGA 内部的 Block RAM
  val mem = Mem(1024, UInt(32.W))
  loadMemoryFromFileInline(mem, "src/main/resources/hex/flow_led.hex")
  
  // 按字地址获取指令
  val iaddr = io.addr >> 2.U
  // 注意: SyncReadMem 的读操作是同步的，输出数据会在下一时钟周期得到
  val memData = mem.read(iaddr)
  
  io.inst := memData
}

// 定义数据存储器模块
class DataMemory extends Module {
  val io = IO(new DBusPortIo())

  // 实例化存储器, 存储 4096 个 32 位字
  val mem = Mem(4096, UInt(32.W))
  // 总线接口给出的地址为字节地址, 右移2位得到字地址
  val daddr = io.addr >> 2.U

  // 这个数据存储器总能一拍就完成读写
  io.done := io.valid

  // 写操作：只有在总线周期有效且 wen 为真时进行写入
  when(io.valid && io.wen) {
    val oldValue = mem(daddr)
    // 如果所有字节均使能, 则一次性写入整个 32 位字
    when(io.byte === "b1111".U) {
      mem(daddr) := io.wdata
    } .otherwise {
      // 分字节写入, 按小端优先顺序组合
      val byte0 = Mux(io.byte(0), io.wdata(7, 0),   oldValue(7, 0))
      val byte1 = Mux(io.byte(1), io.wdata(15, 8),  oldValue(15, 8))
      val byte2 = Mux(io.byte(2), io.wdata(23, 16), oldValue(23, 16))
      val byte3 = Mux(io.byte(3), io.wdata(31, 24), oldValue(31, 24))
      mem(daddr) := Cat(byte3, byte2, byte1, byte0)
    }
  }
  // 读操作：当 valid 信号有效且不是写操作时, 输出对应地址的数据；否则输出 0
  io.rdata := Mux(io.valid && !io.wen, mem(daddr), 0.U)
}


// 读写有一周期延迟的数据存储器, 用于测试当外设未响应时CPU能否正确暂停流水线等待
class DataMemory_Latency extends Module {
  val io = IO(new DBusPortIo())

  // 存储4096个32位字
  val mem = Mem(4096, UInt(32.W))

  // 定义状态：空闲(sIdle) 和 执行(sBusy)
  val sIdle :: sBusy :: Nil = Enum(2)
  val state = RegInit(sIdle)

  // 用于保存上一拍的操作信息
  val wen_reg   = Reg(Bool())
  val addr_reg  = Reg(UInt(WORD_LEN.W))
  val byte_reg  = Reg(UInt(4.W))  
  val wdata_reg = Reg(UInt(WORD_LEN.W))

  // 默认：done 信号拉低, 读数据为0
  io.done := false.B
  io.rdata := 0.U

  switch(state) {
    is(sIdle) {
      // 当总线请求有效时采样输入信号, 并进入忙状态
      when(io.valid) {
        wen_reg   := io.wen
        addr_reg  := io.addr
        byte_reg  := io.byte
        wdata_reg := io.wdata
        state := sBusy
      }
    }
    is(sBusy) {
      // 由于总线提供的是字节地址, 右移2位获得字地址
      val daddr = addr_reg >> 2.U

      when(wen_reg) {
        // 写操作：读取原来的值, 根据字节使能实现分字节写入, 否则一次写入整个字
        val oldValue = mem(daddr)
        when(byte_reg === "b1111".U) {
          mem(daddr) := wdata_reg
        } .otherwise {
          val byte0 = Mux(byte_reg(0), wdata_reg(7, 0),   oldValue(7, 0))
          val byte1 = Mux(byte_reg(1), wdata_reg(15, 8),  oldValue(15, 8))
          val byte2 = Mux(byte_reg(2), wdata_reg(23, 16), oldValue(23, 16))
          val byte3 = Mux(byte_reg(3), wdata_reg(31, 24), oldValue(31, 24))
          mem(daddr) := Cat(byte3, byte2, byte1, byte0)
        }
      } .otherwise {
        // 读操作：输出对应地址的数据
        io.rdata := mem(daddr)
      }
      
      // 操作完成, 将 done 拉高, 并回到空闲状态准备下一次操作
      io.done := true.B
      state := sIdle
    }
  }
}



// 存储器模块, 已经弃用!!!
class Memory extends Module{  
  val io = IO(new Bundle {
    val imem = new ImemPortIo()  // 例化上面定义的指令接口模板
    val dmem = new DBusPortIo()  // 例化上面定义的数据接口模板
  })

  val mem = Mem(4096,UInt(32.W))  // 生成32位宽16KB寄存器作为存储器, 4096×32b=16KB

  loadMemoryFromFileInline(mem,"src/main/resources/hex/ctest.hex")  // 向存储器写入初始程序
  /*  教程里用的8位存储器, 取指时要一次取4个地址的数据, 所以pc寄存器每次+4
  io.imem.inst := Cat(
    mem(io.imem.addr + 3.U(WORD_LEN.W)),
    mem(io.imem.addr + 2.U(WORD_LEN.W)),
    mem(io.imem.addr + 1.U(WORD_LEN.W)),
    mem(io.imem.addr),
  )   // 拼接4个地址存储的32位指令,使用小端排序 
  */

  val iaddr = Wire(UInt(WORD_LEN.W))
  val daddr = Wire(UInt(WORD_LEN.W))
  iaddr := (io.imem.addr >> 2.U(WORD_LEN.W))
  daddr := (io.dmem.addr >> 2.U(WORD_LEN.W))

  io.imem.inst  := mem(iaddr)
  io.dmem.rdata := mem(daddr)
    
  when(io.dmem.wen) {
    mem(daddr) := io.dmem.wdata
  }
}
