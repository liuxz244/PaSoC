package PaSoC

import Instructions._
import Consts._
// 导入common.scala中的Instructions定义和Consts定义
import Decode._        // 使用Decode.scala中定义的功能
import Execute._
import MemAccess._

import chisel3._       // chisel本体
import chisel3.util._  // chisel功能


class PasoRV extends Module{  // CPU内核模块
  val io = IO(new Bundle {
  // 翻转ItemPortIo,即addr输出，inst输入; DtemPortIo同理
  val imem = Flipped(new ItemPortIo())
  val dmem = Flipped(new DtemPortIo())
  val exit = Output(Bool())
  // 输出端口exit在程序处理结束时变为true.B
  })

  val regfile = Mem(32  ,UInt(WORD_LEN.W))  // 生成32个32位寄存器
  val csr_reg = Mem(4096,UInt(WORD_LEN.W))  /*4096个CSR(Control & Status Register,
  控制与状态寄存器,用于中断/异常管理、虚拟存储器设定、显示CPU状态等)*/


  // ----------IF(Instruction Fetch)取指阶段----------

  // 生成初始值为0的PC寄存器，每个循环加4
  val pc_reg = RegInit(START_ADDR)  // START_ADDR在Const中定义为0

  io.imem.addr := pc_reg   // pc_reg作为addr输出
  val inst = io.imem.inst  // inst连接输入端口

  io.exit := (inst === UNIMP)  // 未实现此指令，把它当成退出指令

  val br_flg   = Wire(Bool())            // 分支标志，分支是有条件的改变PC寄存器值
  val br_tag   = Wire(UInt(WORD_LEN.W))  // 分支目标
  val jmp_flg  = (inst === JAL||inst === JALR)  // 取到跳转指令，无条件改变PC寄存器
  val alu_out  = Wire(UInt(WORD_LEN.W))

  val pc_plus4 = pc_reg + 4.U(WORD_LEN.W)  // 这里的+4是指四字节，对应到存储器地址实际只增加1
  val pc_next  = MuxCase(pc_plus4,Seq(
      br_flg  -> br_tag ,
      jmp_flg -> alu_out, // 跳转地址由ALU给出
      (inst === ECALL) -> csr_reg(0x305)  // 发生异常时跳转到CSR中mtvec保存的trap_vector地址
  ))
  pc_reg := pc_next
    

  // ----------ID(Instruction Decode)译码阶段----------
    
  val rs1_addr = inst(19,15)  // rs1寄存器编号是指令的第15-19位
  val rs2_addr = inst(24,20)  // rs2寄存器编号是指令的第20-24位
  val rd_addr  = inst(11,7)   //  rd寄存器编号是指令的第 7-11位
  // rs1/rs2对应指令执行的数据源，rd对应数据要写入的寄存器
  val rs1_data = Mux((rs1_addr =/= 0.U(WORD_LEN.W)),regfile(rs1_addr),0.U(WORD_LEN.W))  
  // 根据寄存器地址的值，选择要读取的寄存器数据
  val rs2_data = Mux((rs2_addr =/= 0.U(WORD_LEN.W)),regfile(rs2_addr),0.U(WORD_LEN.W))  
  // 如果地址不为0，则从寄存器堆中读取数据，如果地址为0，则返回0,因为Risc-V规定0号寄存器的值始终为0
    
  val imm = getImmBundle(inst)  // 使用在Decode.scala中定义的函数获取位宽拓展后的立即数，imm是一个包

  val csignals = opLUT(inst)  // 使用自定义函数对指令使用的功能进行解码
  val exe_fnc :: op1_sel :: op2_sel :: mem_wen :: rf_wen :: wb_sel :: csr_cmd :: Nil = csignals  
  // 将csignals列表的每一项分别赋给exe_fnc等变量，多出的项被抛弃(Nil)

  val op1_data = getOP1_data(op1_sel, rs1_data, pc_reg)
  val op2_data = getOP2_data(op2_sel, rs2_data, imm   )


  // ---------------EX(Execute)执行阶段----------------

  alu_out := ALU(exe_fnc, op1_data, op2_data)
    
  br_flg := branch(exe_fnc, op1_data, op2_data)
  br_tag := pc_reg + imm.b_sext

  // -----------MEM(MEMorary access)访存阶段-----------

  io.dmem.addr  := alu_out  // 访问地址
  io.dmem.wen   := mem_wen  // 是否写入
  io.dmem.wdata := rs2_data // 写入数据
  // 读取数据存储器的功能在写回阶段中
    
  val csr_addr  = Mux(csr_cmd === CSR_E,0x342.U(CSR_ADDR_LEN.W),inst(31,20))  
  // 指令高12位表示CSR地址,当发生异常时将csr_addr设为mcause寄存器，保存当前的CPU模式
  val csr_rdata = csr_reg(csr_addr)  // 读取CSR
  val csr_wdata = getCSR_wdata(csr_cmd, csr_rdata, op1_data)
  when(csr_cmd > 0.U){  // 取指到CSR指令时
    csr_reg(csr_addr) := csr_wdata
  }


  // --------------WB(Write Back)写回阶段--------------
  val rd_data = MuxCase(alu_out,Seq(  // 默认输出alu_out
    (wb_sel === WB_MEM) -> io.dmem.rdata,  // 从存储器读取写回数据
    (wb_sel === WB_PC ) -> pc_plus4, // 本来的下一条指令地址
    (wb_sel === WB_CSR) -> csr_rdata,  // 读取CSR
  ))

  when(rf_wen === REN_S) {
    regfile(rd_addr) := rd_data  // 将数据写回寄存器
  }

  // 仿真时输出信息
  printf(p"pc_reg    : 0x${Hexadecimal(pc_reg)}\n"  )
  printf(p"inst      : 0x${Hexadecimal(inst  )}\n"  )
  printf(p"rs1_addr  : $rs1_addr\n"                 )
  printf(p"rs1_data  : 0x${Hexadecimal(rs1_data)}\n")
  printf(p"rs2_addr  : $rs2_addr\n"                 )
  printf(p"rs2_data  : 0x${Hexadecimal(rs2_data)}\n")
  printf(p"rd_addr   : $rd_addr \n"                 )
  printf(p"rd_data   : 0x${Hexadecimal(rd_data)}\n" )
  //printf(p"dmem.addr : ${io.dmem.addr}\n"                )
  //printf(p"dmem.wen  : ${io.dmem.wen }\n"                )
  //printf(p"dmem.wdata: 0x${Hexadecimal(io.dmem.wdata)}\n")
  printf("----------------------\n")
}
