package PaSoC

import chisel3._       // chisel本体
import Consts._

class ItemPortIo extends Bundle{  // 定义指令输入输出接口
    val addr  = Input( UInt(WORD_LEN.W))  // 存储器地址
    val inst  = Output(UInt(WORD_LEN.W))  // 输出指令
}   // WORD_LEN在上面的Const中定义为32


class DtemPortIo extends Bundle{  // 定义数据输入输出接口
    val addr  = Input( UInt(WORD_LEN.W))  // 存储器地址
    val rdata = Output(UInt(WORD_LEN.W))  // 输出数据

    val wen   = Input( Bool())  // 允许写入信号
    val wdata = Input( UInt(WORD_LEN.W))  //写入数据
}

class decodeBundle() extends Bundle {
  import Consts._
  val exe_fnc = UInt(EXE_FUN_LEN.W) ; val op1_sel = UInt(OP1_LEN.W)
  val op2_sel = UInt(OP2_LEN.W)     ; val mem_wen = UInt(MEN_LEN.W)
  val rf_wen  = UInt(REN_LEN.W)     ; val wb_sel  = UInt(WB_SEL_LEN.W)
  val csr_cmd = UInt(CSR_LEN.W)
}

class immBundle() extends Bundle {
  import Consts._
  val i_sext    = UInt(WORD_LEN.W)
  val s_sext    = UInt(WORD_LEN.W)
  val b_sext    = UInt(WORD_LEN.W)
  val j_sext    = UInt(WORD_LEN.W)
  val u_shifted = UInt(WORD_LEN.W)
  val z_uext    = UInt(WORD_LEN.W)
}
